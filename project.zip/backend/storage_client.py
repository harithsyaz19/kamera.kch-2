"""Object storage helper for IC photos and payment receipts."""
import os
import base64
import logging
import uuid as _uuid
import requests

logger = logging.getLogger(__name__)

STORAGE_URL = "https://integrations.emergentagent.com/objstore/api/v1/storage"
EMERGENT_KEY = os.environ.get("EMERGENT_LLM_KEY", "")
APP_NAME = "kamera-kch"

_storage_key: str | None = None


def init_storage() -> str:
    """Initialize storage session. Called once at startup."""
    global _storage_key
    if _storage_key:
        return _storage_key
    resp = requests.post(
        f"{STORAGE_URL}/init",
        json={"emergent_key": EMERGENT_KEY},
        timeout=30,
    )
    resp.raise_for_status()
    _storage_key = resp.json()["storage_key"]
    return _storage_key


def _reset_key():
    global _storage_key
    _storage_key = None


def put_object(path: str, data: bytes, content_type: str) -> dict:
    """Upload bytes to storage. Returns dict with path/size/etag."""
    key = init_storage()
    resp = requests.put(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key, "Content-Type": content_type},
        data=data,
        timeout=120,
    )
    if resp.status_code == 403:
        _reset_key()
        key = init_storage()
        resp = requests.put(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key, "Content-Type": content_type},
            data=data,
            timeout=120,
        )
    resp.raise_for_status()
    return resp.json()


def get_object(path: str) -> tuple[bytes, str]:
    """Download file from storage. Returns (bytes, content_type)."""
    key = init_storage()
    resp = requests.get(
        f"{STORAGE_URL}/objects/{path}",
        headers={"X-Storage-Key": key},
        timeout=60,
    )
    if resp.status_code == 403:
        _reset_key()
        key = init_storage()
        resp = requests.get(
            f"{STORAGE_URL}/objects/{path}",
            headers={"X-Storage-Key": key},
            timeout=60,
        )
    resp.raise_for_status()
    return resp.content, resp.headers.get("Content-Type", "application/octet-stream")


def _decode_base64(raw_b64: str) -> bytes:
    """Decode a base64 string to bytes, raising ValueError on failure."""
    try:
        return base64.b64decode(raw_b64)
    except Exception as e:
        raise ValueError(f"Invalid base64 data: {e}") from e


def upload_data_url(user_id: str, kind: str, data_url: str) -> dict:
    """Upload a base64 data URL string to storage.
    
    Args:
        user_id: User uploading the file
        kind: Category (e.g. 'ic-front', 'ic-back', 'receipt')
        data_url: Either a data: URL or raw base64 string
    
    Returns:
        dict with 'storage_path', 'content_type', 'size'
    """
    content_type = "image/jpeg"
    raw_b64 = data_url
    if data_url.startswith("data:"):
        header, _, raw_b64 = data_url.partition(",")
        # header looks like: data:image/png;base64
        if ";" in header:
            content_type = header.split(":")[1].split(";")[0]
    
    data = _decode_base64(raw_b64)
    
    ext = content_type.split("/")[-1] if "/" in content_type else "bin"
    file_id = str(_uuid.uuid4())
    path = f"{APP_NAME}/{kind}/{user_id}/{file_id}.{ext}"
    
    result = put_object(path, data, content_type)
    return {
        "storage_path": result["path"],
        "content_type": content_type,
        "size": result.get("size", len(data)),
    }
