"""Backend tests for kamera.kch camera rental.

Coverage:
- Auth: register/login/logout/me
- Cameras: list, detail, availability
- Business info
- Bookings: create (4-step verification + delivery), list, detail
- Receipt upload (payment_review status)
- Admin: list bookings, update booking status
"""
import os
import time
import uuid
import requests
import pytest

BASE_URL = os.environ['REACT_APP_BACKEND_URL'].rstrip('/')
API = f"{BASE_URL}/api"

ADMIN = {"email": "admin@kamera.kch", "password": "admin123"}
CUST = {"email": "customer@test.com", "password": "customer123"}

# Tiny base64 PNG (1x1 transparent)
TINY_PNG_B64 = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII="
)


def _customer_info():
    return {
        "full_name": "TEST Customer",
        "ic_number": "990101-13-1234",
        "phone": "+60123456789",
        "emergency_contact": "+60198765432",
        "social_media": "@testcustomer",
        "address": "123 Test Street, Kuching, Sarawak",
        "ic_photo_front": TINY_PNG_B64,
        "ic_photo_back": TINY_PNG_B64,
    }


# ---------- Fixtures ----------
@pytest.fixture(scope="module")
def cust_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=CUST)
    assert r.status_code == 200, f"Customer login failed: {r.status_code} {r.text}"
    return s


@pytest.fixture(scope="module")
def admin_session():
    s = requests.Session()
    r = s.post(f"{API}/auth/login", json=ADMIN)
    assert r.status_code == 200, f"Admin login failed: {r.status_code} {r.text}"
    return s


# ---------- Auth ----------
class TestAuth:
    def test_login_admin(self):
        r = requests.post(f"{API}/auth/login", json=ADMIN)
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["role"] == "admin"
        assert data["email"] == ADMIN["email"]
        assert "access_token" in r.cookies

    def test_login_customer(self):
        r = requests.post(f"{API}/auth/login", json=CUST)
        assert r.status_code == 200, r.text
        assert r.json()["role"] == "customer"

    def test_login_invalid(self):
        r = requests.post(f"{API}/auth/login", json={"email": "noexist@x.com", "password": "wrong"})
        assert r.status_code == 401

    def test_register_new_user(self):
        unique_email = f"test_user_{uuid.uuid4().hex[:8]}@example.com"
        r = requests.post(f"{API}/auth/register", json={
            "email": unique_email, "password": "Test1234!", "name": "TEST Register"
        })
        assert r.status_code == 201, r.text
        data = r.json()
        assert data["email"] == unique_email
        assert data["role"] == "customer"

    def test_register_duplicate(self):
        r = requests.post(f"{API}/auth/register", json={
            "email": CUST["email"], "password": "xx", "name": "dup"
        })
        assert r.status_code == 400

    def test_auth_me(self, cust_session):
        r = cust_session.get(f"{API}/auth/me")
        assert r.status_code == 200, r.text
        assert r.json()["email"] == CUST["email"]

    def test_me_unauth(self):
        r = requests.get(f"{API}/auth/me")
        assert r.status_code == 401


# ---------- Cameras ----------
class TestCameras:
    def test_cameras_list_7(self):
        r = requests.get(f"{API}/cameras")
        assert r.status_code == 200
        data = r.json()
        assert len(data) == 7, f"Expected 7 cameras, got {len(data)}"
        names = {c["name"]: c["daily_rate"] for c in data}
        assert names["Canon R10"] == 75.0
        assert names["Canon R50"] == 65.0
        assert names["Canon M200"] == 60.0
        assert names["Canon M10"] == 55.0
        assert names["Canon SX740"] == 55.0
        assert names["DJI Action 4"] == 45.0
        assert names["DJI Osmo Pocket 2 Combo"] == 40.0
        # Brand split
        canon = [c for c in data if c["brand"] == "Canon"]
        dji = [c for c in data if c["brand"] == "DJI"]
        assert len(canon) == 5
        assert len(dji) == 2

    def test_camera_detail(self):
        r = requests.get(f"{API}/cameras/canon-r10")
        assert r.status_code == 200
        d = r.json()
        assert d["name"] == "Canon R10"
        assert d["daily_rate"] == 75.0

    def test_camera_detail_404(self):
        r = requests.get(f"{API}/cameras/no-such-cam")
        assert r.status_code == 404

    def test_camera_availability(self):
        r = requests.get(f"{API}/cameras/canon-r10/availability")
        assert r.status_code == 200
        data = r.json()
        assert "blocked_dates" in data
        assert isinstance(data["blocked_dates"], list)


# ---------- Business Info ----------
def test_business_info():
    r = requests.get(f"{API}/business/info")
    assert r.status_code == 200
    d = r.json()
    assert d["bank_account"] == "0143 0136 5022"
    assert d["bank_name"] == "Maybank"
    assert d["cod_fee"] == 15.0
    assert "pickup_locations" in d
    assert len(d["pickup_locations"]) >= 1


# ---------- Booking flow ----------
class TestBookings:
    def test_create_booking_self_pickup(self, cust_session):
        # 3 days * 75 = 225, deposit = 112.5
        payload = {
            "camera_id": "canon-r10",
            "start_date": "2031-03-10",
            "end_date": "2031-03-12",
            "customer_info": _customer_info(),
            "delivery_method": "self_pickup",
            "pickup_location": "SK Jalan Muara Tuang",
            "terms_accepted": True,
        }
        r = cust_session.post(f"{API}/bookings", json=payload)
        assert r.status_code == 201, r.text
        b = r.json()
        assert b["days"] == 3
        assert b["rental_amount"] == 225.0
        assert b["delivery_fee"] == 0.0
        assert b["total_amount"] == 225.0
        assert b["deposit_amount"] == 112.5
        assert b["status"] == "pending_payment"
        assert b["delivery_method"] == "self_pickup"
        pytest.bid_self = b["id"]

    def test_create_booking_cod(self, cust_session):
        # 2 days * 40 = 80 rental, + 15 cod = 95 total, deposit = 40
        payload = {
            "camera_id": "dji-osmo-pocket-2",
            "start_date": "2031-04-01",
            "end_date": "2031-04-02",
            "customer_info": _customer_info(),
            "delivery_method": "cod",
            "delivery_address": "456 Delivery Lane, Kuching",
            "terms_accepted": True,
        }
        r = cust_session.post(f"{API}/bookings", json=payload)
        assert r.status_code == 201, r.text
        b = r.json()
        assert b["rental_amount"] == 80.0
        assert b["delivery_fee"] == 15.0
        assert b["total_amount"] == 95.0
        assert b["deposit_amount"] == 40.0
        pytest.bid_cod = b["id"]

    def test_create_booking_terms_required(self, cust_session):
        payload = {
            "camera_id": "canon-r50",
            "start_date": "2031-05-01",
            "end_date": "2031-05-02",
            "customer_info": _customer_info(),
            "delivery_method": "self_pickup",
            "terms_accepted": False,
        }
        r = cust_session.post(f"{API}/bookings", json=payload)
        assert r.status_code == 400

    def test_create_booking_unauth(self):
        payload = {
            "camera_id": "canon-r10",
            "start_date": "2031-05-01",
            "end_date": "2031-05-02",
            "customer_info": _customer_info(),
            "delivery_method": "self_pickup",
            "terms_accepted": True,
        }
        r = requests.post(f"{API}/bookings", json=payload)
        assert r.status_code == 401

    def test_get_booking(self, cust_session):
        bid = pytest.bid_self
        r = cust_session.get(f"{API}/bookings/{bid}")
        assert r.status_code == 200
        assert r.json()["id"] == bid

    def test_list_my_bookings(self, cust_session):
        r = cust_session.get(f"{API}/bookings")
        assert r.status_code == 200
        ids = [b["id"] for b in r.json()]
        assert pytest.bid_self in ids

    def test_create_booking_stores_ic_as_storage_path(self, cust_session):
        # The first booking should have stored IC photos as storage paths, not base64.
        bid = pytest.bid_self
        r = cust_session.get(f"{API}/bookings/{bid}")
        assert r.status_code == 200
        b = r.json()
        ci = b["customer_info"]
        front = ci["ic_photo_front"]
        back = ci["ic_photo_back"]
        # storage paths must NOT be base64 data URLs
        assert not front.startswith("data:"), f"ic_photo_front still base64: {front[:60]}"
        assert not back.startswith("data:")
        # expected format: kamera-kch/{kind}/{user_id}/{uuid}.{ext}
        assert front.startswith("kamera-kch/ic-front/"), front
        assert back.startswith("kamera-kch/ic-back/"), back
        pytest.ic_front_path = front
        pytest.ic_back_path = back

    def test_upload_receipt(self, cust_session):
        bid = pytest.bid_self
        r = cust_session.post(
            f"{API}/bookings/{bid}/upload-receipt",
            json={"receipt_image": TINY_PNG_B64, "payment_reference": "REF12345"},
        )
        assert r.status_code == 200, r.text

        # Verify status changed to payment_review
        r2 = cust_session.get(f"{API}/bookings/{bid}")
        assert r2.status_code == 200
        b = r2.json()
        assert b["status"] == "payment_review"
        # payment_receipt should now be a storage path, not base64
        receipt_path = b["payment_receipt"]
        assert receipt_path is not None
        assert not receipt_path.startswith("data:"), f"receipt still base64: {receipt_path[:60]}"
        assert receipt_path.startswith("kamera-kch/receipt/"), receipt_path
        assert b["payment_reference"] == "REF12345"
        pytest.receipt_path = receipt_path


# ---------- File serving endpoint (/api/files/{path:path}) ----------
class TestFiles:
    def test_get_file_unauth_401(self):
        # Use a path we know exists (IC front from booking flow)
        path = pytest.ic_front_path
        r = requests.get(f"{API}/files/{path}")
        assert r.status_code == 401, r.text

    def test_get_file_owner_200(self, cust_session):
        path = pytest.ic_front_path
        r = cust_session.get(f"{API}/files/{path}")
        assert r.status_code == 200, r.text
        assert r.headers.get("Content-Type", "").startswith("image/")
        assert len(r.content) > 0

    def test_get_file_admin_200(self, admin_session):
        # Admin can access any user's file
        path = pytest.ic_back_path
        r = admin_session.get(f"{API}/files/{path}")
        assert r.status_code == 200, r.text
        assert len(r.content) > 0

    def test_get_receipt_file_owner_200(self, cust_session):
        path = pytest.receipt_path
        r = cust_session.get(f"{API}/files/{path}")
        assert r.status_code == 200, r.text
        assert len(r.content) > 0

    def test_get_file_404_for_missing_path(self, cust_session):
        # Made-up storage path that won't exist in db.files
        bogus = "kamera-kch/ic-front/nonexistent/aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee.png"
        r = cust_session.get(f"{API}/files/{bogus}")
        assert r.status_code == 404, r.text

    def test_get_file_cross_user_403(self):
        # Register a fresh, unrelated customer and try to access first user's file
        other_email = f"other_{uuid.uuid4().hex[:8]}@example.com"
        s = requests.Session()
        reg = s.post(f"{API}/auth/register", json={
            "email": other_email, "password": "Pass1234!", "name": "TEST Other"
        })
        assert reg.status_code == 201, reg.text
        # The session cookie is set automatically
        path = pytest.ic_front_path
        r = s.get(f"{API}/files/{path}")
        assert r.status_code == 403, f"Expected 403 cross-user, got {r.status_code}: {r.text}"

    def test_get_file_via_query_param_auth(self):
        # img tags cannot send custom headers; ?auth=<jwt> must work.
        # Get a fresh JWT via login (read access_token cookie).
        s = requests.Session()
        r = s.post(f"{API}/auth/login", json=CUST)
        assert r.status_code == 200
        token = s.cookies.get("access_token")
        assert token, "No access_token cookie returned from login"
        path = pytest.ic_front_path
        # Use raw requests (no cookie/header) with ?auth=<jwt>
        r2 = requests.get(f"{API}/files/{path}", params={"auth": token})
        assert r2.status_code == 200, r2.text
        assert len(r2.content) > 0

    def test_get_file_invalid_token_401(self):
        path = pytest.ic_front_path
        r = requests.get(f"{API}/files/{path}", params={"auth": "not-a-valid-jwt"})
        assert r.status_code == 401, r.text

    def test_files_tracking_collection(self, admin_session):
        # Confirm db.files has tracking records by retrieving all 3 known paths
        # successfully via admin; 404 would indicate missing tracking.
        for p in [pytest.ic_front_path, pytest.ic_back_path, pytest.receipt_path]:
            r = admin_session.get(f"{API}/files/{p}")
            assert r.status_code == 200, f"Missing tracking record for {p}: {r.text}"


# ---------- Admin ----------
class TestAdmin:
    def test_admin_lists_all_bookings(self, admin_session):
        r = admin_session.get(f"{API}/bookings")
        assert r.status_code == 200
        assert isinstance(r.json(), list)

    def test_admin_update_status_to_confirmed(self, admin_session):
        bid = pytest.bid_self
        r = admin_session.put(f"{API}/bookings/{bid}/status", json={"status": "confirmed"})
        assert r.status_code == 200, r.text
        # verify
        r2 = admin_session.get(f"{API}/bookings/{bid}")
        b = r2.json()
        assert b["status"] == "confirmed"
        assert b.get("payment_status") == "deposit_paid"

    def test_customer_cannot_update_status(self, cust_session):
        bid = pytest.bid_cod
        r = cust_session.put(f"{API}/bookings/{bid}/status", json={"status": "confirmed"})
        assert r.status_code == 403

    def test_admin_block_dates(self, admin_session):
        r = admin_session.post(
            f"{API}/cameras/canon-m200/block-dates",
            json={"dates": ["2031-06-15", "2031-06-16"]},
        )
        assert r.status_code == 201, r.text
        # verify in availability
        r2 = requests.get(f"{API}/cameras/canon-m200/availability")
        blocked = r2.json()["blocked_dates"]
        assert "2031-06-15" in blocked
        assert "2031-06-16" in blocked


def test_logout(cust_session):
    r = cust_session.post(f"{API}/auth/logout")
    assert r.status_code == 200
