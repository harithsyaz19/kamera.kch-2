# Test Credentials for kamera.kch

## Admin Account
- **Email**: admin@kamera.kch
- **Password**: admin123
- **Role**: admin

## Test Customer Account
- **Email**: customer@test.com
- **Password**: customer123
- **Role**: customer

## Business Info
- **Phone**: +60 12-879 7715
- **Bank**: Maybank
- **Account**: 0143 0136 5022

## Authentication Endpoints
- POST /api/auth/register
- POST /api/auth/login
- POST /api/auth/logout
- GET /api/auth/me

## Camera Models (7 total)
1. Canon R10 - RM75/day
2. Canon R50 - RM65/day
3. Canon M200 - RM60/day
4. Canon M10 - RM55/day
5. Canon SX740 - RM55/day
6. DJI Action 4 - RM45/day
7. DJI Osmo Pocket 2 Combo - RM40/day

## Booking Flow
1. Browse catalog -> Select camera
2. Choose dates on calendar
3. Step 1: Verification form (Name, IC, Phone, Emergency Contact, Social Media, Address, IC Photos)
4. Step 2: Accept Terms & Conditions
5. Step 3: Choose Self Pickup (free) or COD (+RM15)
6. Create booking -> Status: pending_payment
7. Payment page: Show Maybank account & deposit amount
8. Upload payment receipt -> Status: payment_review
9. Admin verifies and confirms -> Status: confirmed
10. Balance paid on pickup

## Payment
- 50% deposit required
- Manual bank transfer to Maybank 0143 0136 5022
- Upload receipt for verification
- Balance paid on pickup
