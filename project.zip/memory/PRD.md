# kamera.kch - Camera Rental Platform PRD

## Original Problem Statement
Build a modern, professional camera rental website with a clean white and maroon color theme for "kamera.kch" - a premium camera rental service in Kuching, Malaysia.

### Business Information
- **Name**: kamera.kch
- **Admin Phone**: +60 12-879 7715
- **Bank**: Maybank
- **Account**: 0143 0136 5022

## Tech Stack
- Frontend: React 19 + React Router 7 + Tailwind + Shadcn UI
- Backend: FastAPI + Motor (async MongoDB)
- Database: MongoDB
- Auth: JWT with httpOnly cookies + bcrypt
- Design: White/Maroon (#6B0F1A) + Playfair Display (headings) + Inter (body)

## User Personas
1. **Customer**: Browses cameras, selects dates, completes verification, pays deposit
2. **Admin**: Manages bookings, verifies payments, updates booking status

## Core Requirements (Static)
- 7 camera models (5 Canon + 2 DJI)
- Real-time availability calendar (blocked dates unclickable)
- 4-step booking flow with identity verification
- Manual Maybank bank transfer (50% deposit) with receipt upload
- Self pickup (free) or COD (+RM15)
- Mobile responsive design
- Terms & Conditions acceptance

## Implemented Features (2026-06-01)
- ✅ Home page with hero, featured cameras, how-it-works, footer
- ✅ Catalog page with brand filter (All/Canon/DJI)
- ✅ Camera detail page with live availability calendar
- ✅ Calendar blocks past dates and booked dates (line-through styling)
- ✅ JWT authentication (register, login, logout) with httpOnly cookies
- ✅ Multi-step booking flow with IC verification, T&C, delivery method
- ✅ **Object storage for IC photos & receipts** (migrated from base64) — uploads go to Emergent object storage, frontend fetches via `/api/files/{path}` with auth (cookie/Bearer/query param) and renders via blob URLs through `AuthImage` component
- ✅ Payment page with Maybank account details (copy buttons) + receipt upload
- ✅ 50% deposit calculation with balance on pickup
- ✅ Booking confirmation page
- ✅ My Bookings page with status badges
- ✅ Admin Dashboard with stats, bookings list, detail modal (uses AuthImage for IC/receipt viewing), status updates
- ✅ Terms & Conditions page
- ✅ WhatsApp integration link
- ✅ Mobile responsive design throughout

## Camera Pricing
| Model | Brand | Daily Rate |
|-------|-------|------------|
| Canon R10 | Canon | RM75 |
| Canon R50 | Canon | RM65 |
| Canon M200 | Canon | RM60 |
| Canon M10 | Canon | RM55 |
| Canon SX740 | Canon | RM55 |
| DJI Action 4 | DJI | RM45 |
| DJI Osmo Pocket 2 Combo | DJI | RM40 |

## Pickup Locations
- SK Jalan Muara Tuang
- Federal Park Matang
- Other (subject to management approval)

## Test Credentials
- **Admin**: admin@kamera.kch / admin123
- **Customer**: customer@test.com / customer123

## Backend API Endpoints
- `/api/auth/register|login|logout|me` - Authentication
- `/api/business/info` - Business details
- `/api/cameras` - List cameras
- `/api/cameras/{id}` - Camera detail
- `/api/cameras/{id}/availability` - Blocked dates
- `/api/cameras/{id}/block-dates` (admin) - Block dates manually
- `/api/bookings` - List/Create bookings
- `/api/bookings/{id}` - Booking detail
- `/api/bookings/{id}/upload-receipt` - Upload payment receipt
- `/api/bookings/{id}/status` (admin) - Update status

## Testing Status
- **Backend**: 100% (24/24 tests pass)
- **Frontend**: All key flows verified working

## Backlog (P1 - Next Phase)
- Email/WhatsApp notifications on booking status change
- Object storage for IC photos and receipts (currently base64 in DB)
- Admin: Manual date blocking UI
- Customer profile page (edit info)
- Booking modification/cancellation
- Search/filter on admin dashboard
- Rental agreement PDF generation
- Damage/return checklist

## Backlog (P2 - Future)
- Push notifications
- Customer reviews/ratings
- Loyalty program / discount codes
- Multi-language (English/Malay/Chinese)
- Analytics dashboard for admin
- Equipment maintenance tracking
